"# arafat-web" 

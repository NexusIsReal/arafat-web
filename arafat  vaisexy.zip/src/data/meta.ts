export const SUBJECT_META: Record<string, { name: string; code: string; color: string }> = {
  phy: { name: 'পদার্থবিজ্ঞান (Physics)', code: 'PHY', color: 'from-blue-500 to-cyan-400' },
  chem: { name: 'রসায়ন (Chemistry)', code: 'CHEM', color: 'from-emerald-500 to-teal-400' },
  bio: { name: 'জীববিজ্ঞান (Biology)', code: 'BIO', color: 'from-green-500 to-lime-400' },
  math: { name: 'গণিত (Mathematics)', code: 'MATH', color: 'from-violet-500 to-purple-400' },
  ict: { name: 'ICT', code: 'ICT', color: 'from-orange-500 to-amber-400' },
  eng: { name: 'English', code: 'ENG', color: 'from-rose-500 to-pink-400' },
  sci: { name: 'বিজ্ঞান (Science)', code: 'SCI', color: 'from-teal-500 to-cyan-400' },
};
